<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mobile";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "call viewandroid()";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
      // output data of each row
    while($row = $result->fetch_assoc()) {

//echo "device ID: " . $row["pid"]. " - City: " . $row["pcity"]. "- Address: " . $row["paddress"]. "- type " . $row["ptype"]. "- size " . $row["psize"]. "- Cost: " . $row["pcost"]. "<br>";
    
echo "<html><body bgcolor='powderblue'>";

echo "<style>
table {
    border-collapse: collapse;
    width: 75%;
}

th, td {
    text-align: left;
    padding: 10px;
}

tr:nth-child(even) {background-color: #f2f2f2;}
</style>";

echo "<center><table border='15'><tr><th>device ID:</th><td>".$row['pid']."</td></tr>";
echo "<tr><th>device Company:</th><td>".$row['pcity']."</td></tr>";
echo "<tr><th>device type:</th><td>".$row['ptype']."</td></tr>";
echo "<tr><th>device Weight:</th><td>".$row['paddress']."</td></tr>";
echo "<tr><th>device size:</th><td>".$row['psize']."</td></tr>";
echo "<tr><th>device Cost:</th><td>".$row['pcost']."</td></tr>";

echo"<br>";

echo "</table></center></body></html>";    

}
} else {
     echo "<h1>No Devices Found</h1>";
}
$conn->close();
?>


<html>
<head>
<body>
<style>
.button {
  display: inline-block;
  padding: 15px 25px;
  font-size: 24px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: black;
  background-color:gol;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
}

.button:hover {background-color:powderblue}

.button:active {
  background-color:grey;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
</style>
<br><br><br>
<center><a href="7.php"><button class="button">BACK</button></a></center>
</body>
</head?
</html>