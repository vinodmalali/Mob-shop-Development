<?php
?>


<html>
<head>

<title>buyer</title>
<style>
.button {
   
  display: inline-block;
  padding: 15px 25px;
  font-size: 24px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;s
  outline: none;
  color: black;
  background-color:white;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
}


.button2:hover {
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
}

.button2:hover {
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
}

.button2:hover {
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
}

</style>
</head>
<body background="im21.jpg">
<br><br><br>
<center><a href="sret2.php"><button class="button button2">IOS</button><br><br></a>	<br>
<a href="sret.php"><button class="button button2">BASIC</button><br><br></a><br>

<a href="sret1.php"><button class="button button2">ANDROID</button><br><br></a><br>

<a href="3.php"><button class="button button2">Back</button><br><br></a><br></center><br><br>

</body>
</html>
