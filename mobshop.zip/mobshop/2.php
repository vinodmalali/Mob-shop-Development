<?php
?>

<html>
<body  background="6.jpg">
<title>register</title>

<h1><font color="white"><center>REGISTER FORM</center></font></h1><br>

<form method="POST" action="form.php">
    <fieldset>
<legend><font color="white" size="6">REGISTER HERE</legend>
   <font color="white" size="6"> User ID<br></font>
    <input type="text" name="uid" placeholder="enter your user id">
    <br><br>
    <font color="white" size="6"> Name:<br></font>
    <input type="text" name="name" placeholder="enter your name">
    <br><br>
    <font color="white" size="6"> Create Password<br></font>
    <input type="password" name="pwd" placeholder="create your password">
    <br><br>
    <font color="white" size="6"> State:<br></font>
    <input type="text" name="state" placeholder="enter your state">
    <br><br>
    <font color="white" size="6">City:<br></font>
    <input type="text" name="city" placeholder="enter your city">
   <br><br>
    <font color="white" size="6">Gender:<br></font>
  <font color="white" size="4"><input type="radio" name="gender" value="male" checked> Male<br>
  <input type="radio" name="gender" value="female"> Female<br>
  <input type="radio" name="gender" value="other"> Other  <br></font><br>

<font color="white" size="6">Mobile Number:<br></font>
    <input type="text" name="mobnum" placeholder="enter your mobile number">
    <br><br>
    
<font color="white" size="6">E-mail:<br></font>
    <input type="text" name="email" placeholder="enter your email address">
    <br><br>
    <font color="white" size="6">Type of User:<br></font>
  <font color="white" size="4"><input type="radio" name="type" value="buyer" checked> BUYER<br>
  <input type="radio" name="type" value="seller"> SELLER<br>
    <br></font>
 

<br>
    <input type="submit" value="REGISTER">
<a href="home.php"><input type="button" value="BACK"/>
</fieldset>
</form>

</body>
</html>
