<?php
?>

<html>
<body  background="pic.jpg">
<title>update</title>
<h1><font color="white"><center>UPDATE PHONE DETAILS</center></h1></font><br>
<form action="/action_page.php">
    <fieldset>
<legend><font color="white" size="6">UPDATE HERE</legend>
<font color="white" size="6">PHONE ID<br></font>
    <input type="text" name="PHONE id" placeholder="give the phone id">
    <br><br>
   <font color="white" size="6">CITY<br></font>
    <input type="text" name="city" placeholder="enter the city">
    <br><br>
    <font color="white" size="6">ADDRESS<br></font>
    <input type="text" name="adress" placeholder="enter the address">
    <br><br>
    
    <font color="white" size="6"> LAPTOP TYPE<br></font>
    <font color="white" size="4"><input type="radio" name="type" value="dos" checked>DOS<br>
  <input type="radio" name="type" value="windows">WINDOWS<br>
    <br><br>
    <font color="white" size="6">LAPTOP MODEL<br></font>
      <input type="text" name="laptop model" placeholder="model of laptop">
   <br><br></font>
    <font color="white" size="6">LAPTOP STATUS<br></font>
    <font color="white" size="4"><input type="radio" name="laptop status" value="available" checked>AVAILABLE<br>
  <input type="radio" name="laptop status" value="unavailable">UNAVAILABLE<br>
    <br><br>
    <input type="submit" value="UPDATE"/>

</fieldset>
</form>

</body>
</html>
