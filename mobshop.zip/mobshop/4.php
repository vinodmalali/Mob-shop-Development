<?php
?>

<html>
<body  background="im23.jpg">
<title>insert</title>
<h1><font color="white"><center>INSERT PHONE</center></h1></font><br>
<form method="post" action="insert.php">
    <fieldset>
<legend><font color="white" size="6">INSERT HERE</legend>
<font color="white" size="6">PHONE ID<br></font>
    <input type="text" name="pid" placeholder="give the PHONE id">
    <br><br>
   <font color="white" size="6"> COMPANY<br></font>
    <input type="text" name="pcity" placeholder="enter the city">
    <br><br>
    
    
    <font color="white" size="6"> PHONE TYPE<br></font>
    <font color="white" size="4"><input type="radio" name="ptype" value="basic" checked>BASIC<br>
  <input type="radio" name="ptype" value="android">ANRDROID<br>
<input type="radio" name="ptype" value="ios">IOS<br>
    <br><br>
   </font>
<font color="white" size="6">WEIGHT<br></font>
    <input type="text" name="paddress" placeholder="enter the address">
    <br><br>
<font color="white" size="6"> SIZE<br></font>
    <input type="text" name="psize" placeholder="enter the city">
    <br><br>
   <font color="white" size="6">PHONE COST<br></font>
      <input type="text" name="pcost" placeholder="cost of the phone">
   <br><br></font>
    
    <input type="submit" value="INSERT"/>
<a href="3.php"><input type="button" value="BACK"/>

</fieldset>
</form>

</body>
</html>
