<?php
?>

<html>
<body  background="im27.jpg">
<title>delete</title>
<h1><font color="white"><center>DELETE PHONE</center></h1></font><br>

<form method="post" action="delete.php">
    <fieldset>
<legend><font color="white" size="6">DELETE HERE</legend>
<font color="white" size="6">PHONE ID<br></font>
    <input type="text" name="pid" placeholder="give the phone id">
    <br><br>
    
    <input type="submit" value="DELETE"/>
<a href="3.php"><input type="button" value="BACK"/>
</fieldset>
</form>

</body>
</html>
