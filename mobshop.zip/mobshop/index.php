<?php
?>


<html>

<background-repeat:no-repeat>
<title>Admin</title>
<h1><font color="maroon"><center>Admin Login</center></h1></font><br>
<form method="post" action="validation2.php">
    <fieldset>
<legend><font color="maroon" size="6">LOGIN HERE</legend>
   <font color="maroon" size="6"> Login id:<br></font>
    <input type="text" name="loginid" placeholder="enter your login id">
    <br><br>
    
    <font color="maroon" size="6"> Password:<br></font>
    <input type="password" name="password" placeholder="enter your password">
    <br><br>
    
    
 <input type="submit" value="Login"/>


</fieldset>
</form>

</body>
</html>
