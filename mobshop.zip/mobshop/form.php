<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "mobile";

$id = $_POST["uid"];
$uname = $_POST["name"];
$upassword = $_POST["pwd"];
$ustate = $_POST["state"];
$ucity = $_POST["city"];
$ugender = $_POST["gender"];
$mob = $_POST["mobnum"];
$uemail = $_POST["email"];
$utype = $_POST["type"];

$conn = new mysqli($servername, $username, $password,$db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "insert into user2 values('$id','$uname','$ugender','$mob','$ustate','$ucity','$uemail','$utype','$upassword')";
$result = mysqli_query($conn,$sql) or die( "could not execute");

$sql1="select * from user2";
if($result1 = mysqli_query($conn,$sql1))
{
$rowcount=mysqli_num_rows($result1);
}
?>


<html>
    
<head>
    <style type="text/css">
html, 
body {
height: 100%;
}

body {
background-image: url("black.jpg");
background-repeat: no-repeat;
background-size: 100%;
}
        h2{
font-size: 50;}
    </style>
    </head>
    <body>
        
        <h1><font color="orange"><marquee>Registered Sucessfully</marquee></font></h1>
		<br><br><br>
		
<style>
.button {
  display: inline-block;
  padding: 15px 25px;
  font-size: 24px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: orange;
  background-color:gol;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
}

.button:hover {background-color:powderblue}

.button:active {
  background-color:grey;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
</style>
<center><a href="login.php"><button class="button">LOGIN HERE</button></a></center>

        </body></head></html>

