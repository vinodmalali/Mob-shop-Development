<html>
<head>
<title>Login By</title>
<style>
body {
	background-repeat:none;
}
</style>
<style>
.button {
  display: inline-block;
  padding: 15px 25px;
  font-size: 24px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: black;
  background-color:gold;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
}

.button:hover {background-color:powderblue}

.button:active {
  background-color:gold;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
</style>
</head>



<body background="apple.jpg">
<style>
h1 {
    font-size: 50px;
}

</style>
<h1><center><font color="black"></center></h1>
<br>
<br><br><br><br><br>
<center><a href="1.php"><button class="button"></font>BUYER</button></a><br><br>
<a href="11.php"><button class="button">SELLER</button></a><br><br>
<a href="home.php" ><button class="button">BACK</button></a></center>
<br>
<br>
</body>
</html>