-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 06, 2021 at 07:20 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mobile`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `viewandroid` ()  NO SQL
select * from device where ptype="android"$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `viewbasic` ()  NO SQL
select * from device where ptype="basic"$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `viewios` ()  NO SQL
select * from device where ptype="ios"$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `password`) VALUES
('', ''),
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `buyer2`
--

CREATE TABLE `buyer2` (
  `uid` varchar(20) DEFAULT NULL,
  `bcity` varchar(20) DEFAULT NULL,
  `bloc` varchar(20) DEFAULT NULL,
  `bemail` varchar(20) DEFAULT NULL,
  `bnum` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buyer2`
--

INSERT INTO `buyer2` (`uid`, `bcity`, `bloc`, `bemail`, `bnum`) VALUES
('1', 'ban', 'abc', 'suraj@abc.com', '9986');

-- --------------------------------------------------------

--
-- Table structure for table `device`
--

CREATE TABLE `device` (
  `pid` varchar(20) NOT NULL,
  `pcity` varchar(20) DEFAULT NULL,
  `paddress` varchar(20) DEFAULT NULL,
  `ptype` varchar(20) DEFAULT NULL,
  `psize` varchar(20) DEFAULT NULL,
  `pcost` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Triggers `device`
--
DELIMITER $$
CREATE TRIGGER `mobile` AFTER DELETE ON `device` FOR EACH ROW BEGIN
insert into solddev values(old.pid,old.pcity,old.paddress,old.ptype,old.psize,old.pcost);
end
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `login2`
--

CREATE TABLE `login2` (
  `uid` varchar(20) DEFAULT NULL,
  `upwd` varchar(20) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login2`
--

INSERT INTO `login2` (`uid`, `upwd`, `type`) VALUES
('1', '$rk', 'buyer'),
('2', 'abc', 'seller');

-- --------------------------------------------------------

--
-- Table structure for table `seller2`
--

CREATE TABLE `seller2` (
  `uid` varchar(20) DEFAULT NULL,
  `selloc` varchar(20) DEFAULT NULL,
  `selemail` varchar(20) DEFAULT NULL,
  `selcity` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seller2`
--

INSERT INTO `seller2` (`uid`, `selloc`, `selemail`, `selcity`) VALUES
('2', 'qwe', 'venki@abc.com', 'ban');

-- --------------------------------------------------------

--
-- Table structure for table `solddev`
--

CREATE TABLE `solddev` (
  `pid` varchar(20) DEFAULT NULL,
  `pcity` varchar(20) DEFAULT NULL,
  `paddress` varchar(100) DEFAULT NULL,
  `ptype` varchar(20) DEFAULT NULL,
  `psize` varchar(20) DEFAULT NULL,
  `pcost` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `solddev`
--

INSERT INTO `solddev` (`pid`, `pcity`, `paddress`, `ptype`, `psize`, `pcost`) VALUES
('5', 'ban', 'qwerty', 'television', 'a156', '40000'),
('5', 'ban', 'qwerty', 'laptop', '15.6', '20000'),
('3', 'ban', 'abcde', 'television', '40', '40000'),
('1', 'ban', 'abcd', 'mobile', '5.5', '15000'),
('3', '', '', 'ios', '', ''),
('222', '', '', 'android', '', ''),
('', '', '', 'basic', '', ''),
('22', 'MI', '', 'basic', '', ''),
('2222', '', '', 'basic', '', ''),
('22222', '', '', 'basic', '', ''),
('', '', '', 'basic', '', ''),
('1', '', '', 'basic', '', ''),
('11', 'NOKIA', '500 GRAM', 'basic', '1.57', '2000'),
('2', '', '', 'android', '', ''),
('222', 'MI', '2 KG', 'android', '6.57', '15000'),
('3', '', '', 'ios', '', ''),
('33', 'APPLE', '1.50 KG', 'ios', '5.45', '70000');

-- --------------------------------------------------------

--
-- Table structure for table `user2`
--

CREATE TABLE `user2` (
  `uid` varchar(20) NOT NULL,
  `uname` varchar(20) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `mob` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `device`
--
ALTER TABLE `device`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `user2`
--
ALTER TABLE `user2`
  ADD PRIMARY KEY (`uid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
