<?php
?>


<html>
<body  background="im29.jpg">
<title>login</title>
<h1><font color="white"><center>LOGIN FORM</center></h1></font><br>
<form method="post" action="validation1.php">
    <fieldset>
<legend><font color="white" size="6">LOGIN HERE</legend>
   <font color="white" size="6"> Login id:<br></font>
    <input type="text" name="loginid" placeholder="enter your login id">
    <br><br>
    
    <font color="white" size="6"> Password:<br></font>
    <input type="password" name="password" placeholder="enter your password">
    <br><br>
    
    
    <input type="submit" value="Login"/>
<a href="login.php"><input type="button" value="Back"/>

</fieldset>
</form>

</body>
</html>
