<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "mobile";

$id = $_POST["pid"];
$city = $_POST["pcity"];
$address = $_POST["paddress"];
$type = $_POST["ptype"];
$size = $_POST["psize"];
$cost = $_POST["pcost"];

$conn = new mysqli($servername, $username, $password,$db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "insert into device values('$id','$city','$address','$type','$size','$cost')";
$result = mysqli_query($conn,$sql) or die( "could not execute");
$sql1="select * from phone";
if($result1 = mysqli_query($conn,$sql1))
{
$rowcount=mysqli_num_rows($result1);
}
?>
<html>
    
<head>
    <style type="text/css">
html, 
body {
height: 100%;
}

body {
background-image: url("grass.jpg");
background-repeat: no-repeat;
background-size: 100%;
}
        h2{
font-size: 50;}
    </style>
    </head>
    <body bgcolor=black>
        
        <h1><font color="white"><marquee>mobile Added Sucessfully</marquee></font></h1>
		<br><br><br>
		<center><a href="3.php"><button class="button">BACK</button></a></center>
        </body></head></html>
