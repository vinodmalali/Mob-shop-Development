<?php
?>


<html>
<head>
<center><font color="maroon"><h1>Mobile Shop Management</h1></font></center><br></br>
<title>mobile shop management</title>
<style>
body {
	background-repeat:none;
}
</style>
<style>
.button {
  display: inline-block;
  padding: 15px 25px;
  font-size: 24px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: black;
  background-color:gold;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
}

.button:hover {background-color:powderblue}

.button:active {
  background-color:gold;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
</style>

</head>



<body background="picc.jpg">

<style>
h1 {
    font-size: 50px;
}

</style>
<h1><center><font color="black"></center></h1>
<br>

<center><a href="2.php"><button class="button"></font>REGISTER</button></a><br><br>
<a href="login.php"><button class="button">LOGIN</button></a></center>
<br>
<br>

</body>
</html>