<?php
?>


<html>
<head>

<title>seller</title>

<style>
.button {
  display: inline-block;
  padding: 15px 25px;
  font-size: 24px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: black;
  background-color:gol;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
}

.button:hover {background-color:powderblue}

.button:active {
  background-color:grey;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}


</style>
</head>

<body background="im28.jpg">

<br><br><br><center><a href="4.php"><button class="button button2">ADD DEVICE</button><br><br><br></a>
<a href="5.php"><button class="button button2">DELETE DEVICE</button><br><br></a><br>
<a href="device.php"><button class="button">DEVICE INFO</button></a> <br><br><br><br><br>

<a href="login.php"><button class="button">BACK</button></a>  </center><br><br>

</center><br><br>

</body>
</html>
