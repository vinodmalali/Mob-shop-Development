<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "mobile";
$uname1 = $_POST["loginid"];
$pwd1 = $_POST["password"];
$conn = new mysqli($servername, $username, $password,$db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
else
echo "Connection Successful";

$sql = "SELECT * from user2 where uid='$uname1' and password='$pwd1' and type='buyer'";
$result = mysqli_query($conn,$sql) or die( "could not execute");
$num_rows = mysqli_num_rows($result);
if ( $num_rows > 0)
{
    header( "Location:7.php");
    
}
else
{
    header("Location:1.php");
}


?>
