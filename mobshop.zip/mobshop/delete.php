<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "mobile";
$id = $_POST["pid"];

$conn = new mysqli($servername, $username, $password,$db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "delete from device where pid='$id'";

$result = mysqli_query($conn,$sql) or die( "Could not executed");
if (mysqli_query($conn, $sql)) {
    echo "";
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}



mysqli_close($conn);

?>

<html>
    
<head>
    <style type="text/css">
html, 
body {
background-image: url("im30.jpg");
background-repeat: no-repeat;
background-size: 100%;

}

        h2{
font-size: 50;}
    </style>
    </head>
    <body bgcolor=black>
        
        <h1><font color="orange"><marquee>Mobile Deleted Successfully</marquee></font></h1><br><br>
<center><a href="3.php"><button class="button">BACK</button></a></center>
        </body></head></html>


